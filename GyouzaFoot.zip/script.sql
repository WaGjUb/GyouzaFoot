-- MySQL dump 10.13  Distrib 5.5.46, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: gyouzafoot
-- ------------------------------------------------------
-- Server version	5.5.46-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cartao_amarelo`
--

DROP TABLE IF EXISTS `cartao_amarelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cartao_amarelo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_participacao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_participacao` (`id_participacao`),
  CONSTRAINT `cartao_amarelo_ibfk_1` FOREIGN KEY (`id_participacao`) REFERENCES `participacao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartao_amarelo`
--

LOCK TABLES `cartao_amarelo` WRITE;
/*!40000 ALTER TABLE `cartao_amarelo` DISABLE KEYS */;
INSERT INTO `cartao_amarelo` VALUES (3,45),(4,48),(5,49),(6,50),(7,65),(8,66);
/*!40000 ALTER TABLE `cartao_amarelo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cartao_vermelho`
--

DROP TABLE IF EXISTS `cartao_vermelho`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cartao_vermelho` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_participacao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_participacao` (`id_participacao`),
  CONSTRAINT `cartao_vermelho_ibfk_1` FOREIGN KEY (`id_participacao`) REFERENCES `participacao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartao_vermelho`
--

LOCK TABLES `cartao_vermelho` WRITE;
/*!40000 ALTER TABLE `cartao_vermelho` DISABLE KEYS */;
INSERT INTO `cartao_vermelho` VALUES (6,48),(7,59);
/*!40000 ALTER TABLE `cartao_vermelho` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contrato`
--

DROP TABLE IF EXISTS `contrato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contrato` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_jogador` int(11) DEFAULT NULL,
  `entrada` date DEFAULT NULL,
  `saida` date DEFAULT NULL,
  `camisa` int(11) DEFAULT NULL,
  `id_posicao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_jogador` (`id_jogador`),
  KEY `id_posicao` (`id_posicao`),
  CONSTRAINT `contrato_ibfk_1` FOREIGN KEY (`id_jogador`) REFERENCES `jogadores` (`id`),
  CONSTRAINT `contrato_ibfk_2` FOREIGN KEY (`id_posicao`) REFERENCES `posicao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrato`
--

LOCK TABLES `contrato` WRITE;
/*!40000 ALTER TABLE `contrato` DISABLE KEYS */;
INSERT INTO `contrato` VALUES (2,1,'2015-12-05','2015-12-05',20,2),(3,5,'3902-03-02','1899-12-31',4,3),(4,6,'2015-02-27','0002-12-31',2,1),(5,7,'2015-03-19','0002-12-31',3,16),(6,8,'2003-05-03','0002-12-31',5,5);
/*!40000 ALTER TABLE `contrato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faltas_cometidas`
--

DROP TABLE IF EXISTS `faltas_cometidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faltas_cometidas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_participacao` int(11) DEFAULT NULL,
  `gravidade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_participacao` (`id_participacao`),
  CONSTRAINT `faltas_cometidas_ibfk_1` FOREIGN KEY (`id_participacao`) REFERENCES `participacao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faltas_cometidas`
--

LOCK TABLES `faltas_cometidas` WRITE;
/*!40000 ALTER TABLE `faltas_cometidas` DISABLE KEYS */;
INSERT INTO `faltas_cometidas` VALUES (5,45,2),(6,63,1);
/*!40000 ALTER TABLE `faltas_cometidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faltas_tomadas`
--

DROP TABLE IF EXISTS `faltas_tomadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faltas_tomadas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_participacao` int(11) DEFAULT NULL,
  `gravidade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_participacao` (`id_participacao`),
  CONSTRAINT `faltas_tomadas_ibfk_1` FOREIGN KEY (`id_participacao`) REFERENCES `participacao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faltas_tomadas`
--

LOCK TABLES `faltas_tomadas` WRITE;
/*!40000 ALTER TABLE `faltas_tomadas` DISABLE KEYS */;
INSERT INTO `faltas_tomadas` VALUES (8,46,1);
/*!40000 ALTER TABLE `faltas_tomadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jogadores`
--

DROP TABLE IF EXISTS `jogadores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jogadores` (
  `nome` varchar(40) DEFAULT NULL,
  `idade` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jogadores`
--

LOCK TABLES `jogadores` WRITE;
/*!40000 ALTER TABLE `jogadores` DISABLE KEYS */;
INSERT INTO `jogadores` VALUES ('testersom',24,1),('Vitorio',19,2),('Romário',4,5),('Daniel Valerio',21,6),('Emely Kauanna',22,7),('Zé Henrique',23,8);
/*!40000 ALTER TABLE `jogadores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jogo`
--

DROP TABLE IF EXISTS `jogo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jogo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_adversario` varchar(100) DEFAULT NULL,
  `PTgyouza` int(11) DEFAULT NULL,
  `PTadversario` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jogo`
--

LOCK TABLES `jogo` WRITE;
/*!40000 ALTER TABLE `jogo` DISABLE KEYS */;
INSERT INTO `jogo` VALUES (19,'BaGuoFanFoot',1,1,'2000-02-01'),(20,'asdf',2,1,'2000-02-01'),(21,'MianTiaoFoot',1,0,'2004-02-02'),(22,'ChaoMianFoot',6,0,'2000-02-05'),(23,'MotoXFoot',3,0,'2000-02-01'),(24,'TomixFoot',1,2,'2000-02-01'),(25,'HambugerFoot',2,1,'2002-02-01'),(26,'ChaoMianFoot',0,0,'2005-02-12');
/*!40000 ALTER TABLE `jogo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participacao`
--

DROP TABLE IF EXISTS `participacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `participacao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_jogador` int(11) DEFAULT NULL,
  `id_jogo` int(11) DEFAULT NULL,
  `gol_contra` int(11) DEFAULT NULL,
  `gol_valido` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_jogador` (`id_jogador`),
  KEY `id_jogo` (`id_jogo`),
  CONSTRAINT `participacao_ibfk_1` FOREIGN KEY (`id_jogador`) REFERENCES `jogadores` (`id`),
  CONSTRAINT `participacao_ibfk_2` FOREIGN KEY (`id_jogo`) REFERENCES `jogo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participacao`
--

LOCK TABLES `participacao` WRITE;
/*!40000 ALTER TABLE `participacao` DISABLE KEYS */;
INSERT INTO `participacao` VALUES (45,1,21,0,0),(46,2,21,0,1),(47,5,21,0,0),(48,6,21,0,0),(49,7,21,0,0),(50,8,21,0,0),(51,1,22,0,0),(52,2,22,0,0),(53,5,22,0,0),(54,6,22,0,0),(55,8,22,0,0),(56,1,23,0,0),(57,2,23,0,3),(58,7,23,0,0),(59,8,23,0,0),(60,1,24,0,0),(61,2,24,0,1),(62,5,24,0,0),(63,8,24,0,0),(64,1,25,0,2),(65,2,25,0,0),(66,5,25,0,0),(67,6,25,0,0),(68,8,25,0,0),(69,1,26,0,0),(70,2,26,0,0),(71,5,26,0,0),(72,6,26,0,0),(73,7,26,0,0),(74,8,26,0,0);
/*!40000 ALTER TABLE `participacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posicao`
--

DROP TABLE IF EXISTS `posicao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posicao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(40) DEFAULT NULL,
  `sigla` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posicao`
--

LOCK TABLES `posicao` WRITE;
/*!40000 ALTER TABLE `posicao` DISABLE KEYS */;
INSERT INTO `posicao` VALUES (1,'zagueiro','zg'),(2,'lateral esquerdo','lt'),(3,'lateral direito','lt'),(4,'libero','lb'),(5,'volante','vol'),(6,'ala esquerda','ala'),(7,'ala direita','ala'),(8,'meia ligacao','mel'),(9,'medio centro','mec'),(10,'meio lateral direito','mcl'),(11,'meio lateral esquerdo','mcl'),(12,'medio ofensivo','mo'),(13,'asa direito','asa'),(14,'asa esquerdo','asa'),(15,'ponta esquerda','ex'),(16,'ponta direita','ex'),(17,'segundo atacante','sa'),(18,'centroavante','ca');
/*!40000 ALTER TABLE `posicao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suspensao`
--

DROP TABLE IF EXISTS `suspensao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suspensao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_participacao` int(11) DEFAULT NULL,
  `qtde_jogos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_participacao` (`id_participacao`),
  CONSTRAINT `suspensao_ibfk_1` FOREIGN KEY (`id_participacao`) REFERENCES `participacao` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suspensao`
--

LOCK TABLES `suspensao` WRITE;
/*!40000 ALTER TABLE `suspensao` DISABLE KEYS */;
INSERT INTO `suspensao` VALUES (2,48,3),(3,59,3),(4,73,5);
/*!40000 ALTER TABLE `suspensao` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-12-10 23:45:30
